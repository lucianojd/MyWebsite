#include <iostream>

using namespace std;

int main()
{
	system("java Engine.Board");
	
	return 0;
}