# CodeBreaker
A single player version of the board game Mastermind.
Requires java versions 8 or higher.
To play, click on the CodeBreaker.bat file.